package com.photomagic.ai;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends ComponentActivity {
    private ImageView preview;
    private Bitmap original;
    private Bitmap edited;
    private TextView status;
    private ActivityResultLauncher<String> picker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        picker = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) loadImage(uri);
            }
        );

        buildUi();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(17, 16, 32));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("✦ PhotoMagic AI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Make every photo look its best");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        root.addView(subtitle);

        Button choose = makeButton("＋ Choose photo");
        choose.setOnClickListener(v -> picker.launch("image/*"));
        root.addView(choose);

        preview = new ImageView(this);
        preview.setBackgroundColor(Color.rgb(37, 34, 57));
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams =
            new LinearLayout.LayoutParams(-1, dp(330));
        imageParams.setMargins(0, dp(16), 0, dp(14));
        root.addView(preview, imageParams);

        status = new TextView(this);
        status.setText("Choose a photo to start editing.");
        status.setTextColor(Color.LTGRAY);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(4), 0, dp(12));
        root.addView(status);

        addTool(root, "Auto Correct", "Improve brightness, contrast and colour", this::autoCorrect);
        addTool(root, "Remove People", "AI background-person removal (model integration next)", this::notReady);
        addTool(root, "Body Slim", "Natural body shaping (model integration next)", this::notReady);
        addTool(root, "Background Editor", "Blur or replace the background (model integration next)", this::notReady);
        addTool(root, "Undo", "Restore the original photo", this::undo);

        Button save = makeButton("Save HD photo");
        save.setOnClickListener(v -> saveImage());
        LinearLayout.LayoutParams saveParams =
            new LinearLayout.LayoutParams(-1, dp(52));
        saveParams.setMargins(0, dp(16), 0, 0);
        root.addView(save, saveParams);

        setContentView(scroll);
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(15);
        return button;
    }

    private void addTool(LinearLayout root, String title, String description, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackgroundColor(Color.rgb(35, 32, 55));

        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, dp(5), 0, dp(5));
        root.addView(card, params);

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(16);
        heading.setTypeface(null, 1);
        card.addView(heading);

        TextView detail = new TextView(this);
        detail.setText(description);
        detail.setTextColor(Color.LTGRAY);
        detail.setTextSize(12);
        card.addView(detail);

        card.setOnClickListener(v -> {
            if (original == null) {
                toast("Choose a photo first.");
                return;
            }
            action.run();
        });
    }

    private void loadImage(Uri uri) {
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            if (bitmap == null) {
                toast("This image could not be opened.");
                return;
            }
            original = bitmap;
            edited = original.copy(Bitmap.Config.ARGB_8888, true);
            preview.setImageBitmap(edited);
            status.setText("Photo loaded: " + original.getWidth() + " × " + original.getHeight());
        } catch (Exception exception) {
            toast("Could not open this photo.");
        }
    }

    private void autoCorrect() {
        if (original == null) return;

        int width = original.getWidth();
        int height = original.getHeight();
        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[width * height];
        original.getPixels(pixels, 0, width, 0, 0, width, height);

        for (int i = 0; i < pixels.length; i++) {
            int color = pixels[i];
            int red = clamp((int) ((Color.red(color) - 128) * 1.10 + 134));
            int green = clamp((int) ((Color.green(color) - 128) * 1.10 + 134));
            int blue = clamp((int) ((Color.blue(color) - 128) * 1.10 + 134));
            pixels[i] = Color.argb(Color.alpha(color), red, green, blue);
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height);
        edited = output;
        preview.setImageBitmap(edited);
        status.setText("Auto Correct applied.");
    }

    private int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private void undo() {
        if (original == null) return;
        edited = original.copy(Bitmap.Config.ARGB_8888, true);
        preview.setImageBitmap(edited);
        status.setText("Original photo restored.");
    }

    private void notReady() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("AI model integration needed")
            .setMessage("This feature is not active in this starter build. We will add the required on-device AI model in a later step.")
            .setPositiveButton("OK", null)
            .show();
    }

    private void saveImage() {
        if (edited == null) {
            toast("Choose a photo first.");
            return;
        }

        Uri savedUri = null;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,
                "PhotoMagic_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoMagicAI");

            savedUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (savedUri == null) throw new Exception("Could not create image file");

            try (OutputStream output = getContentResolver().openOutputStream(savedUri)) {
                if (output == null || !edited.compress(Bitmap.CompressFormat.JPEG, 95, output)) {
                    throw new Exception("Could not write image");
                }
            }
            toast("Saved in Pictures/PhotoMagicAI");
        } catch (Exception exception) {
            if (savedUri != null) {
                getContentResolver().delete(savedUri, null, null);
            }
            toast("Could not save photo.");
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
